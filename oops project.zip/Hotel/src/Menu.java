import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) throws IOException{
    	System.out.println("          --------------------------------------");
    	System.out.println("          --------------HOTEL---------------");
    	System.out.println("          -------------ARCADIA----------------");
    	System.out.println("          --------------DELHI-----------------");
    	int flag=0;
    	int cid;
    	int temp;
    	Main temp1;
    	while (flag==0) {
    		System.out.println("\n************************");
    		System.out.println("a. Check in");
    		System.out.println("b. Check out");
    		System.out.println("c. Additional Packages");
    		System.out.println("d. Restaurant");
    		System.out.println("e. Taxi Service");
    		System.out.println("f. Report");
    		System.out.println("q. Quit");
    		System.out.println("Enter Your choice: ");
    		Scanner in=new Scanner(System.in);
    		char c=in.next().charAt(0);
    		System.out.println("************************");		
    		if (c=='a') {
    			temp1= new Main();
    		}    		
    		else if (c=='b'){
    			System.out.println("Enter Your Customer Id: ");
    			cid=in.nextInt();
    			Main.Check_out(cid);  			
    		}   		
    		else if (c=='c') {			
    			System.out.println("Enter Your Customer Id: ");
    			cid=in.nextInt();
    			temp=Main.check_cid(cid); //check cid
    			if(temp==0) {
    				System.out.println("Invalid Customer Id");
    			}
    			else {
    					Package.Package_Menu(cid);
    				}
    		}   		
    		else if(c=='d') {
    			System.out.println("Enter Your Customer Id: ");
    			cid=in.nextInt();
    			temp=Main.check_cid(cid); //check cid
    			if(temp==0) {
    				System.out.println("Invalid Customer Id");
    			}
    			else {
    				restaurant.Restaurant(cid);
    				}
    		}
    		else if(c=='e') {
    			{
    				taxi obj=new taxi();
    				obj.book();
    				obj.print_bill();
    			}
    		}
    		else if(c=='f') {
    			Main.report();
    		}
    		
    		else if(c=='q') {
    			flag=1;
    		}
    		else {
    			System.out.println("Invalid Entry");
    		}		
    	}
    }
}
