import java.util.*;
import java.io.*;

public class Main implements Serializable{
	String name,Address,Phone_no;
    int Customer_id,room,days;
   public Double Bill;

    public void Display() {
    	System.out.println("\nCustomer_id       "+"Name       "+"Address       "+"Phone_no       "+"Duration");
    	System.out.println("------------------------------------------------------------------------------------------------");
    	System.out.println(this.Customer_id+"                          "+this.name+"   "+this.Address+"   "+this.Phone_no+"   "+this.days);
    }
    public static void Display(ArrayList<Main> list){
    	Main x;
    	System.out.println("Customer_id       "+"Name       "+"Address       "+"Phone_no       "+"Duration");
    	System.out.println("------------------------------------------------------------------------------------------------");
    	 for (int i = 0; i < list.size(); i++) {
	       x=list.get(i);  
	       System.out.println(x.Customer_id+"                          "+x.name+"   "+x.Address+"   "+x.Phone_no+"   "+x.days);
	    }
    	
    }
    public Main() throws IOException{
        		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
    			Customer_id=this.Customer_id_gen();
    			System.out.println("Enter your Name:");
    			name = in.readLine();  
    			System.out.println("Enter your Address:");
	    		Address = in.readLine();  
	    		System.out.println("Enter your Phone Number:");
	    		Phone_no = in.readLine();  
	    		System.out.println("Enter the duration of the stay: ");
	    		days=Integer.parseInt(in.readLine()); 
	    		this.Display();
	    		System.out.println("\n------ HOTEL ROOMS INFO ------");
	            System.out.println("1.INTERCONNECTING ROOMS");
	            System.out.println("price=Rs:2500 per day");
	            System.out.println("2.HOLLYWOOD TWIN ROOM");
	            System.out.println("price=Rs:3000 per day");
	            System.out.println("3.DUPLEX ROOMS");
	            System.out.println("price=Rs:4000 per day");
	            System.out.println("4.CABANA ROOMS");
	            System.out.println("price=Rs:4500 per day")  ;    
	            System.out.println("5.SUITE ROOMS");
	            System.out.println("price=Rs:5000 per day");
	            System.out.println("------------------------------------------\n");
	            System.out.println("Enter your choice: ");
	    		room = Integer.parseInt(in.readLine()); 
	    		Bill=cal_room_bill(room);
	    		this.advanced_payment();
	    		this.store_customer_data(); //saving to file
	    		
	    		
    }	
  //Customer id generation
    int Customer_id_gen() {
    	int cid=0;
        // Getting the file by creating object of File class
        File f = new File("a.dat");
 
        // Checking if the specified file exists or not
        if (f.exists()){
        	 try{
                 InputStream inputstream=new FileInputStream("cid.dat");
                 cid=inputstream.read()+1;//cid :
                 inputstream.close();
            }
            catch (FileNotFoundException e2){
                 System.out.println("File not found :(");
            }
            catch(IOException e2){
                 System.out.println("Close error");
            }
        	//clearing data
        	 try {
				new FileWriter("cid.dat", false).close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        	 //writing new
        	 try{
                 OutputStream outputStream= new FileOutputStream("cid.dat");
                 outputStream.write(cid);
                 outputStream.close();
                 }
                 catch (FileNotFoundException e){
                      System.out.println("File not found :(");
                 }
                 catch(IOException e){
                      System.out.println("Close error");
                 }//writing new complete

        }
        else{
        	cid=1;
        	File file = new File("a.dat");
        	try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
        	try{
                OutputStream outputStream= new FileOutputStream("cid.dat");
                outputStream.write(cid);
                outputStream.close();
                }
                catch (FileNotFoundException e){
                     System.out.println("File not found :(");
                }
                catch(IOException e){
                     System.out.println("Close error");
                }//writing first time complete
        }//else
		return cid;
    }
//---------------------------------------------------------
void   advanced_payment() {
			System.out.println("\n--------ADVANCE  PAYMENT----------");
			System.out.println("------------------1000RS------------------");
			System.out.println("-----------ENJOY YOUR STAY :)---------");
}

//adding data
void   store_customer_data(){
	 
	
	File f = new File("customer.ser");
	ArrayList<Main> list = new ArrayList<>();
	if (f.exists()) {
		//reading old
		try{
		    FileInputStream readData = new FileInputStream("customer.ser");
		    ObjectInputStream readStream = new ObjectInputStream(readData);
		    list = (ArrayList<Main>) readStream.readObject();
	   	    list.add(this);
		    readStream.close();
		    
		}catch (Exception e) {
		    e.printStackTrace();
		}
		//clearing data
   	 try {
			new FileWriter("customer.ser", false).close();
		} catch (IOException e) {
			e.printStackTrace();
		}
   //writing new
   	try{
   	    FileOutputStream writeData = new FileOutputStream("customer.ser");
   	    ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
   	    writeStream.writeObject(list);
   	    writeStream.flush();
   	    writeStream.close();

   	}catch (IOException e) {
   	    e.printStackTrace();
   	}//writing new complete
 
	}//if complete
	
	else {
		list.add(this);
    	File file = new File("customer.ser");
    	try {
			file.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    	try{
       	    FileOutputStream writeData = new FileOutputStream("customer.ser");
       	    ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
       	    writeStream.writeObject(list);
       	    writeStream.flush();
       	    writeStream.close();
       	}catch (IOException e) {
       	    e.printStackTrace();
       	}//writing first time complete

	} //else
	
}
//display cutomer data
static void data() {
	try{
	    FileInputStream readData = new FileInputStream("customer.ser");
	    ObjectInputStream readStream = new ObjectInputStream(readData);

	    ArrayList<Main> list = (ArrayList<Main>) readStream.readObject();
	    readStream.close();
	    Main.Display(list);
	}catch (Exception e) {
	    e.printStackTrace();
	}
}
//caclulcation room bill
Double cal_room_bill(int room) {
	Double bill=0.0;
	if (room==1) 
		bill+=2500*this.days;
	else if(room==2)
		bill+=3000*this.days;
	else if(room==3)
		bill+=4000*this.days;
	else if(room==4)
		bill+=4500*this.days;
	else if(room==5)
		bill+=5000*this.days;
	return bill;
}
//////////////////////////////////////////
public static int check_cid(Integer cid){
	try{
	    FileInputStream readData = new FileInputStream("customer.ser");
	    ObjectInputStream readStream = new ObjectInputStream(readData);
	    ArrayList<Main> list = (ArrayList<Main>) readStream.readObject();
	    readStream.close();
	    Integer cid_temp;
	    Main x;//
	    for (int i = 0; i < list.size(); i++) {
	        x=list.get(i);
	        cid_temp=x.Customer_id;
	        if(cid_temp.equals(cid)) {
	        	System.out.println("------------------------------------------------------------------------------------------------");	
	        	System.out.println("Customer_id       "+"Name       ");
	        	System.out.println(x.Customer_id+"                          "+x.name+"\nVerified");
	        	System.out.println("------------------------------------------------------------------------------------------------");
	        	return 1;
	        }
	}
	}
	catch (Exception e) {
	    e.printStackTrace();
	}
	return 0;
	
}
//Update  the bill of additional packages and restaurant
public static void update_bill(int cid,Double bill) {
	 ArrayList<Main> list = new ArrayList<Main>();
	try{
	    FileInputStream readData = new FileInputStream("customer.ser");
	    ObjectInputStream readStream = new ObjectInputStream(readData);

	    list = (ArrayList<Main>) readStream.readObject();//old bill
	    readStream.close();
	}
	catch (IOException e) {
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	//read old bill to array list
	    Integer cid_temp;
	    Main x;//
	    ArrayList<Main> list_new = new ArrayList<Main>();//storing updated bill in new array
	  //clearing data
   	 try {
			new FileWriter("cid.dat", false).close();
		} catch (IOException e) {
			e.printStackTrace();
		}
   	 
   	 //clearing data complete
	    for (int i = 0; i < list.size(); i++) {
	        x=list.get(i);
	        cid_temp=x.Customer_id;
	        if(cid_temp.equals(cid)) {
	        	x.Bill+=bill;
	        	list_new.add(x);
	        	break;
	        }
	     list_new.add(x);
	    }

	   //writing to new array complete
	   //writing new arraylist to file
	 	try{
	    	    FileOutputStream writeData = new FileOutputStream("customer.ser");
	    	    ObjectOutputStream writeStream = new ObjectOutputStream(writeData);
	    	    writeStream.writeObject(list_new);
	    	    writeStream.flush();
	    	    writeStream.close();

	    	}catch (IOException e) {
	    	    e.printStackTrace();
	    	}//writing new complete

}
//check_out
public static void Check_out(int cid){
	int temp;
	Scanner in=new Scanner(System.in);
	try{
	    FileInputStream readData = new FileInputStream("customer.ser");
	    ObjectInputStream readStream = new ObjectInputStream(readData);
	    ArrayList<Main> list = (ArrayList<Main>) readStream.readObject();
	    readStream.close();
	    Integer cid_temp;
	    Main x;//
	    for (int i = 0; i < list.size(); i++) {
	        x=list.get(i);
	        cid_temp=x.Customer_id;
	        if(cid_temp.equals(cid)) {
	        	System.out.println("------------------------------------------------------------------------------------------------");	
	        	System.out.println("\nCustomer_id       "+"Name       "+"Total Amount");
	        	System.out.println("------------------------------------------------------------------------------------------------");
	        	System.out.println(x.Customer_id+"                          "+x.name+"   "+(x.Bill-1000));
	        	System.out.println("------------------------------------------------------------------------------------------------");
	        }
	}
	}
	catch (Exception e) {
	    e.printStackTrace();
	}
}
//report
public static void report() throws IOException {
	BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter the admin password: ");
	String Password=in.readLine();
	if(Password.equals("2444"))
	{
		System.out.println("Acces Granted");	
	try{
		  FileInputStream readData = new FileInputStream("customer.ser");
		  ObjectInputStream readStream = new ObjectInputStream(readData);
		 ArrayList<Main> list = (ArrayList<Main>) readStream.readObject();
		 readStream.close();
	    Main x;//
	    System.out.println("------------------------------------------------------------------------------------------------");	
	    System.out.println("\nCustomer_id       "+"Name       "+"Address       "+"Phone_no       "+"Duration"+"      Bill");
	    for (int i = 0; i < list.size(); i++) {
	        x=list.get(i);
	        System.out.println("------------------------------------------------------------------------------------------------");
	        System.out.println(x.Customer_id+"              "+x.name+"   "+x.Address+"   "+x.Phone_no+"   "+x.days+"  "+x.Bill);
	        System.out.println("------------------------------------------------------------------------------------------------");
	    }

	}
	catch (Exception e) {
	    e.printStackTrace();
	}
	}
	else {
		System.out.println("Acces Denied");	
	}
	
	
	
	
	
}




}
    



