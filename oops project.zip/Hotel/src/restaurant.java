import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class restaurant {
	
	
public static void Restaurant(int cid){
	String loop_bill,n;
	int c=0,q=0,p=0,b=0,t=0;
	ArrayList<String> temp_bill = new ArrayList<String>();
	System.out.println("Welcome to ARCADIA\n");
	System.out.println("BIRYANIS:");
	System.out.println("\tNON-VEG\t\t\t\t\t\tVEG");
	System.out.println("1.Chicken Biryani\t  - Rs 210\t\t10.Veg.Biryani\t    - Rs 154\n2.Mutton Biryani\t  - Rs 253\t\t11.Veg.Family Pack  - Rs 383\n3.Chicken Family Pack\t  - Rs 552\t\t12.Veg.Supreme Pack - Rs 574\n4.Mutton Family Pack\t  - Rs 576\n5.Special Chicken Biryani - Rs 337\n6.Special Mutton Biryani  - Rs 351\n7.Supreme Chicken Biryani - Rs 784\n8.Supreme Mutton Biryani  - Rs 819\n9.Egg Biryani\t\t  - Rs 154");
	System.out.println("\nSTARTERS:");
    System.out.println("\tNON-VEG\t\t\t\t\tVEG");
    System.out.println("13.Chilli Chicken - Rs 264\t\t16.Paneer 65\t  - Rs 196\n14.Chicken 65\t  - Rs 264\t\t17.Veg.Manchurian - Rs 189\n15.Pepper Chicken - Rs 264");
    System.out.println("\nKEBABS:");
    System.out.println("\tNON-VEG");
    System.out.println("18.Chicken Tikka Kebab\t   - Rs 243\n19.Tandoori Chicken (Half) - Rs 243\n20.Tandoori Chicken (Full) - Rs 379\n21.Chicken Reshmi Kebab    - Rs 243\n22.Chicken Garlic Kebab    - Rs 243");
    System.out.println("\nCURRIES:");
    System.out.println("\tNON-VEG\t\t\t\t\tVEG");
    System.out.println("23.Butter Chicken Boneless - Rs 246\t24.Nizami Handi - Rs 171");
    System.out.println("\nINDIAN BREADS:");
    System.out.println("25.Tandoori Roti - Rs 40\n26.Rumali Roti - Rs 40");
    System.out.println("\nDESSERTS:");
    System.out.println("27.Qubani Ka Meetha 250 Gms - Rs 107\n28.Double Ka Meetha - Rs 73");
    System.out.println("\nBEVERAGES:");
    System.out.println("29.Diet Coke\t|30.Thums Up\t|31.Mineral Water\t|32.Maaza\n33.Sprite\t|34.Coke Tin\t|35.Coke\t\t|36.Fanta\t\tMRP");
    //Taking Order from the Customer
    int[] priceHotel={210,253,552,576,337,351,784,819,154,154,383,574,264,264,264,196,189,243,243,379,243,243,246,171,40,40,107,73,40,30,15,30,35,40,55,35};
    String[] foodHotel={"Chicken Biryani","Mutton Biryani","Chicken Family Pack","Mutton Family Pack","Special Chicken Biryani","Special Mutton Biryani","Supreme Chicken Biryani","Supreme Mutton Biryani","Egg Biryani","Veg.Biryani","Veg.Family Pack","Veg.Supreme Pack","Chilli Chicken","Chicken 65","Pepper Chicken","Paneer 65","Veg.Manchurian","Chicken Tikka Kebab","Tandoori Chicken (Half)","Tandoori Chicken (Full)","Chicken Reshmi Kebab","Chicken Garlic Kebab","Butter Chicken Boneless","Nizami Handi","Tandoori Roti","Rumali Roti","Qubani Ka Meetha 250 Gms","Double Ka Meetha","Diet Coke","Thums Up","Mineral Water","Maaza","Sprite","Coke Tin","Coke","Fanta"};
    while(true){
    	System.out.println("Enter your choice: {press 0 when complete}");
    	Scanner in=new Scanner(System.in);
    	c=in.nextInt();
    	if(c==0) {
    		break;
    	}
    	c-=1;//:)
    	p=priceHotel[c];//individual price
    	n=foodHotel[c];
    	System.out.println("Enter quantity");
    	q=in.nextInt();
    	b=p*q;//bill
    	t+=b;
    	//food name    qty  price
    	loop_bill=n+"                 "+q+"        "+b;
    	temp_bill.add(loop_bill);    	
    }
    String x;
    System.out.println("------------------------------------------------------------------------------------------------");
 	System.out.println("Food                                                 "+"Qty      "+"Price      ");
 	 for (int i = 0; i < temp_bill.size(); i++) {
 	       x=temp_bill.get(i);  
 	       System.out.println(x);
 	    }
 	System.out.println("------------------------------------------TOTAL---------------------------------------------");
 	System.out.println("------------------------------------------"+t+"---------------------------------------------");
	System.out.println("------------------------------------------------------------------------------------------------");
	//updating bill of customer object
	Main.update_bill(cid,(double) t);
	
	}


}
