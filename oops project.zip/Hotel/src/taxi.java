import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class taxi 
{ 
	String name;
	long phoneno;
	double bill;
	int kms;
	String time;	
	
	public void book() 
	{
		
		Scanner in=new Scanner (System.in);
	    System.out.println("enter your name");
	    name=in.nextLine();
	    System.out.println("enter your phone no.");
	    phoneno=in.nextLong();
		int i;
	    int j;
	    int n;
	    int k;
	
	    System.out.println("Choose type of booking");
		System.out.println("1.Daily (pickup,drop)");
		System.out.println("2.Rental (hourly based)");
		System.out.println("3.Outstation (tourisrm)");
		System.out.println("4.exit");
		i=in.nextInt();
		if(i==1)
		{
			System.out.println("select one service");
			System.out.println("1.pickup");
			System.out.println("2.drop");
			j=in.nextInt();
			if(j==1)
			{
				System.out.println("where you are");
	    		System.out.println("1.Airport");
	    		System.out.println("2.Railway Station");
	    		System.out.println("3.Bus Stand");
	    		n=in.nextInt();
	    		if(n==1)
	    		{
	    			System.out.println("Estimated bill");
    				System.out.println("DISTANCE TRAVELLED ---- 23 Km");
    				System.out.println("TIME TO REACH DESTINATION ---- 35 min");
    				System.out.println("In which car you want to come");
    				System.out.println("1.MINI\nEstimated bill-	``--->255");
    				System.out.println("2.SEDAN\nEstimated bill--->336");
    				System.out.println("3.SUV\nEstimated bill----->585");
    				System.out.println("4.Lux\\nEstimated bill---->1219");
    				k=in.nextInt();
    				try
    				{
    					if(k==1)
    						bill=255;
    					else if(k==2)
    						bill=336;
    					else if(k==3)
    						bill=585;

    					else if(k==4)
    						bill=1219;
    				}
    				finally
    				{
    					kms=23;
    					time="35 min";
    					System.out.println("you have successfully booked have a good day ");
    				}
	    		}
	    		else if(n==2)
	    		{
	    			System.out.println("DISTANCE TRAVELLED ---- 18 Km");
    				System.out.println("TIME TO REACH DESTINATION ---- 32 min");
    				System.out.println("In which car you want to come");
    				System.out.println("1.MINI\nEstimated bill---->227");
    				System.out.println("2.SEDAN\nEstimated bill--->304");
    				System.out.println("3.SUV\nEstimated bill----->473");
    				System.out.println("4.Lux\nEstimated bill----->1242");
    				k=in.nextInt();
    				try
    				{
    					if(k==1)
    						bill=227;
    					else if(k==2)
    						bill=304;
    					else if(k==3)
    						bill=473;
    					else if(k==4)
    						bill=1242;
    				}
    				finally
    				{
    					kms=18;
    					time="32 min";
    					System.out.println("you have successfully booked have a good day ");
    				}
	    		}
	    		else if(n==3)
	    		{
	    			System.out.println("DISTANCE TRAVELLED ---- 9 Km");
    				System.out.println("TIME TO REACH DESTINATION ---- 16 min");
    				System.out.println("In which car you want to come");
    				System.out.println("1.MINI\nEstimated bill---->143");
    				System.out.println("2.SEDAN\nEstimated bill--->190");
    				System.out.println("3.SUV\nEstimated bill----->272");
    				System.out.println("4.Lux\nEstimated bill----->826");
    				k=in.nextInt();
    				try
    				{
    					if(k==1)
    						bill=143;
    					else if(k==2)
    						bill=190;
    					else if(k==3)
    						bill=272;
    					else if(k==4)
    						bill=826;
    				}
    				finally
    				{
    					kms=9;
    					time="16 min";
    					System.out.println("you have successfully booked have a good day ");
    				}
	    		}
			}
			else if(j==2)
			{
				System.out.println("where you want to go");
	    		System.out.println("1.Airport");
	    		System.out.println("2.Railway Station");
	    		System.out.println("3.Bus Stand");
	    		n=in.nextInt();
	    		if(n==1)
	    		{
	    			System.out.println("DISTANCE TRAVELLED ---- 23 Km");
    				System.out.println("TIME TO REACH DESTINATION ---- 35 min\n");
    				System.out.println("In which car you want to go");
    				System.out.println("1.MINI\nEstimated bill---->255");
    				System.out.println("2.SEDAN\nEstimated bill--->336");
    				System.out.println("3.SUV\nEstimated bill----->585");
    				System.out.println("4.Lux\nEstimated bill----->1219");
    				k=in.nextInt();
    				try
    				{
    					if(k==1)
    						bill=255;
    					else if(k==2)
    						bill=336;

    					else if(k==3)
    						bill=585;

    					else if(k==4)
    						bill=1219;
    				}
    				finally
    				{
    					kms=23;
    					time="35 min";
    					System.out.println("you have successfully booked have a good day ");
    				}
	    		}
	    		else if(n==2)
	    		{
	    			System.out.println("DISTANCE TRAVELLED ---- 18 Km");
    				System.out.println("TIME TO REACH DESTINATION ---- 32 min\n");
    				System.out.println("In which car you want to go");
    				System.out.println("1.MINI\nEstimated bill---->227");
    				System.out.println("2.SEDAN\nEstimated bill--->304");				    				
    				System.out.println("3.SUV\nEstimated bill----->473");
    				System.out.println("4.Lux\nEstimated bill----->1242");
    				k=in.nextInt();
    				try
    				{
    					if(k==1)
    						bill=227;
    					else if(k==2)
    						bill=304;
    					else if(k==3)
    						bill=473;
    					else if(k==4)
    						bill=1242;
    				}
    				finally
    				{
    					kms=18;
    					time="32 min";
    					System.out.println("you have successfully booked have a good day ");
    				}
	    		}
	    		else if(n==3)
	    		{
	    			System.out.println("DISTANCE TRAVELLED ---- 9 Km");
    				System.out.println("TIME TO REACH DESTINATION ---- 16 min\n");
    				System.out.println("In which car you want to go");
    				System.out.println("1.MINI\nEstimated bill---->140");
    				System.out.println("2.SEDAN\nEstimated bill--->190");
    				System.out.println("3.SUV\nEstimated bill----->272");
    				System.out.println("4.Lux\nEstimated bill----->826");
    				k=in.nextInt();
    		   	    try
    				{
    					if(k==1)
    						bill=143;
    					else if(k==2)
    						bill=190;
    					else if(k==3)
    						bill=272;
    					else if(k==4)
    						bill=826;
    				}
    				finally
    				{
    					kms=9;
    					time="16 min";
    					System.out.println("you have successfully booked have a good day ");
    				}	
	    		}
			}
			
		}
		else if(i==2)
		{
			System.out.println("Select one service");
	    	System.out.println("1.1Hr/10Km");
	    	System.out.println("2.2Hr/20Km");
	    	System.out.println("3.4Hr/40Km");
	    	System.out.println("4.6Hr/60Km");
	    	j=in.nextInt();
	    	if(j==1)
	    	{
	    		System.out.println("DISTANCE TRAVELLED ---- 10 Km");
				System.out.println("TIME ---- 1hr\n");
				System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill---->199");
				System.out.println("2.SEDAN\nEstimated bill--->230");
				System.out.println("3.SUV\nEstimated bill----->329");
				System.out.println("4.Lux\nEstimated bill----->919");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=199;
					else if(k==2)
						bill=230;
					else if(k==3)
						bill=329;
					else if(k==4)
						bill=919;
				}
				finally
				{
					kms=10;
					time="1 hr";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
	    	else if(j==2)
	    	{
	    		System.out.println("DISTANCE TRAVELLED ---- 20 Km");
				System.out.println("TIME ---- 2hr\n");
				System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->379");
				System.out.println("2.SEDAN\nEstimated bill--->440");
				System.out.println("3.SUV\nEstimated bill--->579");
				System.out.println("4.Lux\nEstimated bill--->2289");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=379;
					else if(k==2)
						bill=440;
					else if(k==3)
						bill=579;
					else if(k==4)
						bill=2289;
				}
				finally
				{
					kms=20;
					time="2 hr";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
	    	else if(j==3)
	    	{
	    		System.out.println("DISTANCE TRAVELLED ---- 40 Km");
				System.out.println("TIME ---- 4hr\n");
				System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->729");
				System.out.println("2.SEDAN\nEstimated bill--->846");
				System.out.println("3.SUV\nEstimated bill--->1109");
				System.out.println("4.Lux\nEstimated bill--->4299");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=729;
					else if(k==2)
						bill=846;
					else if(k==3)
						bill=1109;
					else if(k==4)
						bill=4299;
				}
				finally
				{
					kms=40;
					time="4 hr";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
	    	else if (j==4)
	    	{
	    		System.out.println("DISTANCE---- 60 Km");
				System.out.println("TIME ---- 6hr\n");
				System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->1049");
				System.out.println("2.SEDAN\nEstimated bill--->1264");
				System.out.println("3.SUV\nEstimated bill--->1721");
				System.out.println("4.Lux\nEstimated bill--->6325");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=1049;
					else if(k==2)
						bill=1264;
					else if(k==3)
						bill=1721;
					else if(k==4)
						bill=6325;
				}
				finally
				{
					kms=60;
					time="6 hr";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
		}
		else if(i==3)
		{
			System.out.println("Select a place");
	    	System.out.println("1.JAIPUR");
	    	System.out.println("2.NAINITAL");
	    	System.out.println("3.AGRA");
	    	System.out.println("4.DEHRADUN");
	    	j=in.nextInt();
	    	if(j==1)
	    	{
	    		System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->3019");
				System.out.println("2.SEDAN\nEstimated bill--->3843");
				System.out.println("3.SUV\nEstimated bill--->5794");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=3019;
					else if(k==2)
						bill=3843;
					else if(k==3)
						bill=5794;
				}
				finally
				{
					kms=259;
					time="5 hr";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
	    	else if(j==2)
	    	{
	    		System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->6266");
				System.out.println("2.SEDAN\nEstimated bill--->7095");
				System.out.println("3.SUV\nEstimated bill--->8246");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=6266;
					else if(k==2)
						bill=7095;
					else if(k==3)
						bill=8246;
				}
				finally
				{
					kms=319;
					time="6 hr 37 min";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
	    	else if(j==3) 
	    	{
	    		System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->3333");
				System.out.println("2.SEDAN\nEstimated bill--->3671");
				System.out.println("3.SUV\nEstimated bill--->5221");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=3333;
					else if(k==2)
						bill=3671;
					else if(k==3)
						bill=5221;
				}
				finally
				{
					kms=224;
					time="3 hr 22 min";
					System.out.println("you have successfully booked have a good day ");
				}
	    	}
	    	else if(j==4)
	    	{
	    		System.out.println("In which car you want to go");
				System.out.println("1.MINI\nEstimated bill--->3991");
				System.out.println("2.SEDAN\nEstimated bill--->6162");
				System.out.println("3.SUV\nEstimated bill--->6930");
				k=in.nextInt();
				try
				{
					if(k==1)
						bill=3991;
					else if(k==2)
						bill=6162;
					else if(k==3)
						bill=6930;
				}
				finally
				{
					kms=234;
					time="4 hr 46 min";
					System.out.println("you have successfully booked have a good day ");
				}	
	    	}
		}
		else if(i==4)
		{
			System.exit(0);
		}		
	}
	public void print_bill()
	{
		System.out.println("----------------------------BILL--------------------------------");
		System.out.println("NAME       :-  "+name);
		System.out.println("PHONE NO.   :-  "+phoneno);
		System.out.println("DISTANCE"+"     "+"ESTIMATED DURATION"+"     "+"     "+"AMOUNT");
		System.out.println(kms+"                      "+time+"             "+bill);
		System.out.println("------------------------Enjoy The Ride--------------------------");
	}

}



