import java.io.IOException;
import java.util.Scanner;

public class Package{
	public static void Package_Menu(int cid){
		Double bill=0.0;
		int flag = 1;
		Scanner in=new Scanner(System.in);
		System.out.println("1) Fitness\r\n"
				+ "2) Spa\r\n"
				+ "3) Saloon\r\n"
				+ "Select Service:\r\n"
				+ "");	
		int choice=in.nextInt();
		if(choice==1) {
			bill=Package.fitness();
		}
		else if(choice==2) {
			bill=Package.spa();
		}
		else if(choice==3) {
			bill=Package.saloon();
		}	

		Main.update_bill(cid,bill);
		System.out.println("*******************************");
		System.out.println("<<<Booking Sucess>>>");
		System.out.println("*******************************");
	}
	/////
	private static Double fitness() {
		Double h,bill;
		System.out.println("Rate for 1hr >>500rs");
		Scanner in=new Scanner(System.in);
		System.out.println("Enter number of hours:");
		h=(double) in.nextInt();
        bill=500*h;
        return bill;
	}
	////
	private static Double spa() {
		Double c,bill=0.0;
		System.out.println("SPA AND WELLNESS CENTRE\r\n"+
		"choose the type of massage\r\n"+
		"1)oil massage>>400rs\r\n"+
		"2)acupunture>>500rs\r\n"+
		"3)full body massage>>1000rs\r\n"+
		"Enter your choice:");
		Scanner in=new Scanner(System.in);
		c=(double) in.nextInt();
		if(c==1)
			bill=400.0;
		else if(c==2)
			bill=500.0;
		else if(c==3)
			bill=1000.0;	
        return bill;
	}
	/////
	private static Double saloon() {
		Double h,bill=0.0;
		System.out.println("SALOON\r\n"+
				"Choose the service\r\n"+
				"1)Blow Dry>>300rs\r\n"+
				"2)Hair Cut>>400rs\r\n"+
				"3)Eyebrow Care>>550rs\r\n"+
				"4)Hair Color>>450rs\r\n"+
				"Enter your choice:");
		Scanner in=new Scanner(System.in);
		h=(double) in.nextInt();
        if(h==1)
        	bill=300.0;
        else if(h==2)
        	bill=400.0;
        if(h==3)
        	bill=550.0;
        if(h==4)
        	bill=450.0;
        return bill;
	}

}
